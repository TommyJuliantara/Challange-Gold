import sqlite3

conn = sqlite3.connect('data/binar_data_science.db')
print("Opened database successfully")

conn.execute('C:\Users\Tommy Juliantara\binar-data-science\data.csv') 

conn.commit()
print("Records created successfully")
conn.close() 