import sqlite3

conn = sqlite3.connect('data/binar_data_science.db')

print("Opened database successfully")